import j.i.Couple;
import j.m.JSON;
import j.m.XList;
import j.m.XMap;
import j.m.XResult;
import j.w.WmClient;
import j.w.WsClient;
import j.w.WsProxy;
public class Main {
    public static void main(String[] args) {
        System.out.println(JSON.toPrettyJSON(WsProxy.load(ExpWS.class).getStuList()));
    }
}
//为了和服务端解除接口耦合,这个个接口定义是根据服务发布文档客户端自己定义的也可以从服务端运行的浏览器页面上拷贝获得
@WsClient("http://localhost/ws/demo/ExpWS/")
interface ExpWS {

    @WmClient("add.wm")
    int add(int p0, int p1);

    XResult<Integer> bornYear(XMap p0); //method signature recommended by the author.

    int div(int p0, int p1); //get the value of x div y . may produce an '/ by zero' Exception

    XList<Stu> getStuList();

    @WmClient("hello-name")
    String greeting(String p0);

    Couple<String, XList<String>> getCouple(String p0, XList<String> p1);

    String queryString(XMap p0);

    String hello();

    XList<XList<Integer>> getListList();
}
//服务端的强类型客户端需要有类型定义为了和服务端解除接口耦合包含的成员可以和服务端不一致，类型转换器只会匹配一致的部分
class Stu {
    private int id;
    private String name;
    private Integer age;
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Integer getAge() {
        return age;
    }
    public void setAge(Integer age) {
        this.age = age;
    }
}